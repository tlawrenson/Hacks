/**
 * Author: Tanner Lawrenson and Amanda Whitlatch
 * Date: 2018/8/23
 *
 * A simple hello world program in C
 *
 */
#include<stdlib.h>
#include<stdio.h>

int main(int argc, char **argv) {

  printf(Tanner Lawrenson, Computer Science\n");
  printf(Amanda Whitlatch Khilou Max, Computer Science\n");

  return 0;
}
